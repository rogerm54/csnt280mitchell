<?php
   require_once('helpers.php');
   add_user('Jane','Doe','janedoe@gmail.com','janey');
   echo check_id('janedoe@gmail.com','janey') . "\n";
   add_user('John','Doe','johndoe@gmail.com','john');
   echo check_id('johndoe@gmail.com','john') . "\n";
?>
