<?php
   // login.php
   //echo 'This is a test';
?>
<html>
	<body>
		<form method="post" action="handleLogin.php">
			Username:
			<input type="text" name="user"/><br />
			Password:
			<input type="password" name="pass"/><br />
			<br />
			<input type="submit" value="Enter"/>
		</form>
	</body>
</html>
