<?php
   require_once('../../project1/helpers.php');
   $pdo = connect();
   if (!$pdo) {
      die("Could not connect");
   }
   echo "Connected successfully\n";
   echo do_hash('test') . "\n";
   $salt = make_salt('test');
   echo $salt . "\n";
   echo make_enc_pass('test',$salt) . "\n";
   add_user('Jane','Doe','janedoe@gmail.com','janey');
   echo check_id('janedoe@gmail.com','janey') . "\n";
   echo check_id('johndoe@gmail.com','john') . "\n";
?>
