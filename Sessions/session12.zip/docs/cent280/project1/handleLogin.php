<?php
   require_once('../../project1/helpers.php');
   $pdo = connect();
   if (!$pdo) {
		die("Could not connect");
	}
	//echo "Connected";
	$username = $_POST["user"];
	$password = $_POST["pass"];
	//echo "username: $username <br />";
	//echo "password: $password <br />";
	$user_id = check_id($username,$password);
	//echo "user_id: $user_id <br />";
	if ($user_id > 0) {
		echo "User authenticated";
	}
	else {
		header("Location: login.php");
		exit();
	}
?>





