-- init.sql
drop table if exists users cascade;

create table users (
   id serial,
   first_name text,
   last_name text,
   e_mail text unique,
   password text,
   salt text,
   enc_pass text,
   primary key (id)
);
