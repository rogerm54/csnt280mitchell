<?php
    function connect() {
      $pdoString = "pgsql:host='172.19.0.1' dbname='proj1_db' " .
         " user='bob' password='somepass'";
      $pdo = new PDO($pdoString);
      return $pdo;
   }
   function do_hash($text) {
      return hash('sha512',$text);
   }
   function make_salt($text) {
      return do_hash(time() . $text);
   }
   function make_enc_pass($text, $salt) {
      return do_hash($text . $salt);
   }
   function add_user($fn, $ln, $e_mail, $pass) {
	  $pdo = connect();
	  if (!$pdo) {
		  return;
	  }
	  $sql = "insert into users (first_name, last_name, " .
	     "e_mail, salt, enc_pass) values (:fn, :ln, " .
	     ":e_mail, :salt, :enc_pass)";
	  $statement = $pdo->prepare($sql);
	  $myarray = array();
	  $myarray[':fn'] = $fn;
	  $myarray[':ln'] = $ln;
	  $myarray[':e_mail'] = $e_mail;
	  $myarray[':salt'] = make_salt($pass);
	  $salt = $myarray[':salt'];
	  $myarray[':enc_pass'] = make_enc_pass($pass, $salt);
	  $statement->execute($myarray);
   }
   function check_id($user, $pass) {
      $pdo = connect();
      if (!$pdo) {
		 return;
	  }
	  $sql = "select * from users where e_mail='$user'";
	  $results = $pdo->query($sql);
	  $count = $results->rowCount();
	  if ($count != 1) {
		 return -1;
	  }
	  else if ($count == 1) {
		 $row = $results->fetch(PDO::FETCH_ASSOC);
		 $salt = $row['salt'];
		 $enc_pass = $row['enc_pass'];
		 if (do_hash($pass . $salt) == $enc_pass) {
			return $row['id'];
		 }
		 else {
			return -2;
		 }
	  }
   }
?>
