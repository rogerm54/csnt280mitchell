import hashlib
print(hashlib.sha512(b'test').hexdigest())
print("")
print(hashlib.sha512(b'A_very@long+password1234567890^hard_to_guess').hexdigest())
