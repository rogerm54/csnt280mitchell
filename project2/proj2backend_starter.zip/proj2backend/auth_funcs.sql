-- auth_funcs.sql
create or replace function do_hash(_text text)
   returns text as
   $func$
      begin
         return encode(digest(_text,'sha512'),'hex');
      end;
   $func$
   language 'plpgsql';

create or replace function make_salt(_text text)
   returns text as
   $func$
      begin
         return do_hash(now() || _text);
      end;
   $func$
   language 'plpgsql';

create or replace function make_enc_pass(_text text)
   returns text as
   $func$
      begin
         return do_hash(_text || make_salt(_text));
      end;
   $func$
   language 'plpgsql';

create or replace function add_user(_fn text, _ln text, 
   _user text, _pass text)
   returns void as
   $func$
      begin
         insert into users (first_name, last_name, e_mail,
            salt, enc_pass) values (_fn, _ln, _user,
            make_salt(_pass), make_enc_pass(_pass));
      end;
   $func$
   language 'plpgsql';

create or replace function check_id(_user text, _pass text)
   returns integer as
   $func$
      declare
         rec record;
      begin
         select * into rec from users where e_mail=_user;
         if not found then
            return -1;
         else
            if (do_hash(_pass || rec.salt) = rec.enc_pass) then
               return rec.id;
            else
               return -1;
            end if;
         end if;
      end;
   $func$
   language 'plpgsql';
   
