infile = open("functions.txt","r")
line = infile.readline() # skip first line
line = infile.readline() # skip second line
line = infile.readline() # skip third line
lines = infile.readlines()
infile.close()
outfile = open("drop.sql","w")
for i in range(0,len(lines) - 2):
    tokens = lines[i].strip().split("|")
    #print(tokens[1],tokens[3])
    if (tokens[1].strip() != 'digest'):
        func = tokens[1] + '(' + tokens[3] + ');'
        print('alter extension pgcrypto drop function ' + func)
        outfile.write('alter extension pgcrypto drop function ')
        outfile.write(func + '\n')
outfile.write('\n')
for i in range(0,len(lines) - 2):
    tokens = lines[i].strip().split("|")
    #print(tokens[1],tokens[3])
    if (tokens[1].strip() != 'digest'):
        func = tokens[1] + '(' + tokens[3] + ');'
        print('drop function ' + func)
        outfile.write('drop function ' + func + '\n')
outfile.close()
