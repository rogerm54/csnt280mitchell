-- init.sql
drop table if exists users cascade;
drop table if exists proposals cascade;
drop table if exists bridge_tbl cascade;

create table users (
   id serial,
   first_name text,
   last_name text,
   e_mail text unique,
   password text,
   salt text,
   enc_pass text,
   primary key (id)
);

create table proposals (
   id serial,
   title text unique,
   story text,
   primary key (id)
);

create table bridge_tbl (
   id serial,
   user_id integer references users(id),
   proposal_id integer references proposals(id),
   primary key (id)
);

