<?php
   require_once('../../include/project2.php');
   $pdo = connect();
   if (!$pdo) {
      die("Could not connect");
   }
   $username = $_POST["email"];
   $password = $_POST["pass"];
   $sql = "select check_id(:user, :pass)";
   $statement = $pdo->prepare($sql);
   $myarray = array();
   $myarray[':user'] = $username;
   $myarray[':pass'] = $password;
   $statement->execute($myarray);
   $row = $statement->fetch(PDO::FETCH_ASSOC);
   $uid = $row['check_id'];
   if ($uid > 0) {
      // set session variables
      session_start();
      $_SESSION['user_id'] = $uid;
      $_SESSION['email'] = $username;
      header("Location: home.php");
      exit();
   }
   else {
      header("Location: login.php");
      exit();
   }   
?>
