<?php
	// login.php
?>
<html>
	<body>
		<form method="POST" action="handleLogin.php">
			EMAIL:
			<input type="text" name="email"/><br />
			PASSWORD: 
			<input type="password" name="pass"/><br />
			<br />
			<input type="submit" value="Login"/>
		</form>
	</body>
</html>
