<?php
   require_once('../../include/project2.php');
   $pdo = connect();
   if (!$pdo) {
      die("Could not connect");
   }
   session_start();
   $creator = $_SESSION["email"];
   $title = ...; // Get POST variable from form
   $story = ...; // FILL IN THE MISSING CODE
   $userlist = $_POST["userlist"];
   $emails = array();
   $emails = explode(',', $userlist);
   $emails[] = $creator;
   $sql = "..."; // FILL IN THE MISSING CODE
   // Use a prepared statement here...example nearby
   
   $pid = $row['add_proposal'];
   if ($pid > 0) {
      $sql = "..."; // FILL IN THE MISSING CODE
      $statement = $pdo->prepare($sql);
      $myarray = array();
      $myarray[':pid'] = $pid;
      foreach($emails as $value) {
         $myarray[':email'] = trim($value);
         $statement->execute($myarray);
         $row = $statement->fetch(PDO::FETCH_ASSOC);
	  }
      // set session variables
      $_SESSION['proposal_id'] = $pid;
      header("Location: home.php");
      exit();
   }
   else {
      header("Location: home.php");
      exit();
   }   
?>
