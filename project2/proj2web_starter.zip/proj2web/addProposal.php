<?php
	// addProposol.php
	session_start();
?>
<html>
	<body>
		<form method="POST" action="handleAddProposal.php">
			Proposal Title:
			<input type="text" name="title"/><br />
			Description: <br />
			<textarea id="story" name="story" rows="10" cols="50" ></textarea><br /><br />
			User Emails (separated by commas): <br />
			<textarea id="users" name="userlist" rows="5" cols="25" ></textarea><br />
			<br /><br />
			<input type="submit" name="submit" value="Submit"/>
		</form>
	</body>
</html>
