<?php
	session_start();
	require_once('../../include/project2.php');
	$pdo = connect();
	if (!$pdo) {
		die("Could not connect");
	}
	echo "<h1>Proposals Home Page</h1>";
	$username = $_SESSION['email'];
	echo $username . " is working on these proposals: \n";
	$sql = "select ..."; // FINISH QUERY
	$statement = $pdo->prepare($sql);
	$myarray = array();
	$myarray[':email'] = $username;
	$statement->execute($myarray);
	$result = $statement->fetchAll();
	
	echo '<html><body><table><tr>';
	echo '</tr>';
	$i = 0;
	foreach ($result as $row) 
	{
		echo '<tr>';
		$count = count($row);
		$y = 0;
		while ($y < $count)
		{
			echo '<td>' . $row[$y] . '</td>';
			$y = $y + 1;
		}
		echo '</tr>';
		$i = $i + 1;
	}
	echo '</table>';
	echo '<form method="POST" action="addProposal.php">';
	echo '<input type="submit" value="Add Proposal"/><br /></form>';
	echo '</body></html>';
?>
